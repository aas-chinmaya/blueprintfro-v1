const mongoose = require('mongoose');
require('dotenv').config();

const connections = {};

const connectDatabases = async () => {
  try {
    // Main DB
    await mongoose.connect(process.env.MONGO_URI);
    connections.main = mongoose.connection;
    console.log('Connected to Main DB (Blueprint Project)');

    // HRMS DB
    const hrmsConnection = await mongoose.createConnection(process.env.HRMS_URI);
    connections.hrms = hrmsConnection;
    console.log('Connected to HRMS DB');

    return connections;
  } catch (error) {
    console.error(' Error connecting to databases:', error);
    throw error;
  }
};

module.exports = { connectDatabases, connections };
