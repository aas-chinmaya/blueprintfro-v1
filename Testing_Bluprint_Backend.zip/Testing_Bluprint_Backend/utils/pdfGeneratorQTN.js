


const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');
const ejs = require('ejs');
 
module.exports = async function generateQuotationPDF(quotation) {
  try {
    // Step 1: Load EJS Template and Logo
    const templatePath = path.resolve(__dirname, '../templates/quotationTemplate.ejs');
    const logoPath = path.resolve(__dirname, '../utils/logo.png');
 
    const logoData = fs.readFileSync(logoPath);
    const logoBase64 = `data:image/png;base64,${logoData.toString('base64')}`;
 
    // Step 2: Render HTML from EJS
    const html = await ejs.renderFile(templatePath, { quotation, logoBase64 });
 
    // Step 3: Launch Puppeteer (Ubuntu Safe Config)
    const browser = await puppeteer.launch({
      headless: 'new', // or true if Puppeteer <19
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-zygote'
      ]
    });
 
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
 
    // Step 4: Generate PDF Buffer
   const pdfBuffer = await page.pdf({
  format: 'A4',
  printBackground: true,
  margin: { top: 0, right: 0, bottom: 0, left: 0 }
});
 
    await browser.close();
    return pdfBuffer;
  } catch (err) {
    console.error('Error generating PDF:', err);
    throw err;
  }
};
 
 
 