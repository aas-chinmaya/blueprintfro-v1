const BudgetAccount = require("../../Model/BudgetModel/BudgetAccount");



exports.createBudgetAccount = async (req, res) => {
//  try {
//     const { projectId } = req.params;
//     // const accountData = req.body;

//     if (!projectId) return res.status(400).json({ message: "Project ID is required" });

//     // Check if account already exists for the project
//     const existingAccount = await BudgetAccount.findOne({ projectId, isDeleted: false });
//     if (existingAccount)
//       return res.status(400).json({ message: "Budget account already exists for this project" });
//     const account = new BudgetAccount({ projectId });

//     // const account = new BudgetAccount({ projectId, ...accountData });
//     await account.save();

//     res.status(201).json({ message: "Budget account created", data: account });
//   } catch (error) {
//     console.log("ytrdcdftftf",error);
//     res.status(500).json({ message: "Internal server error", error });
//   }
 try {
    const { projectId } = req.params;
    const { initialAmount } = req.body;

    if (!projectId) {
      return res.status(400).json({ message: 'Project ID is required' });
    }

    // Check if account already exists
    const existingAccount = await BudgetAccount.findOne({ projectId, isDeleted: false });
    if (existingAccount) {
      return res.status(400).json({ message: 'Budget account already exists for this project' });
    }

    // Create new account
    const account = new BudgetAccount({
      projectId,
      initialAmount: initialAmount || 0,
    });

    await account.save();

    return res.status(201).json({ message: 'Budget account created', data: account });
  } catch (error) {
    console.error('Error creating budget account:', error.message);
    return res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};



exports.getBudgetAccountById = async (req, res) => {
  try {
    const { accountId } = req.params;
    const account = await BudgetAccount.findOne({ accountId, isDeleted: false })
      .populate("projectId", "name")
      .populate("transactions.by", "name email");

    if (!account) return res.status(404).json({ message: "Budget account not found" });

    res.status(200).json({ data: account });
  } catch (error) {
    res.status(500).json({ message: "Internal server error", error });
  }
};


// Fetch all budget accounts for a specific project
exports.fetchBudgetAccountsByProject = async (req, res) => {
  try {
    const { projectId } = req.params;
    const accounts = await BudgetAccount.find({ projectId, isDeleted: false })
      .populate("projectId", "name")
      .populate("transactions.by", "name email");

    res.status(200).json({ data: accounts });
  } catch (error) {
    res.status(500).json({ message: "Internal server error", error });
  }
};



// Add budget allocation (transaction) to account
exports.addBudgetAllocation = async (req, res) => {
  try {
    const { accountId } = req.params;
    const allocationData = req.body;

    const account = await BudgetAccount.findOne({ accountId, isDeleted: false });
    if (!account) return res.status(404).json({ message: "Budget account not found" });


    const updatedAccount = await account.addTransaction(allocationData);
    res.status(200).json({ message: "Budget allocation added", data: updatedAccount });
  } catch (error) {
    res.status(500).json({ message: "Internal server error", error });
  }
};

// Soft delete transaction
exports.softDeleteTransaction = async (req, res) => {
  try {
    const { accountId, txnId } = req.params;

    const account = await BudgetAccount.findOne({ accountId, isDeleted: false });
    if (!account) return res.status(404).json({ message: "Budget account not found" });

    await account.removeTransaction(txnId);
    res.status(200).json({ message: "Transaction soft deleted", data: account });
  } catch (error) {
    res.status(500).json({ message: "Internal server error", error });
  }
};

// Soft delete budget account
exports.softDeleteBudgetAccount = async (req, res) => {
  try {
    const { accountId } = req.params;

    const account = await BudgetAccount.findOne({ accountId, isDeleted: false });
    if (!account) return res.status(404).json({ message: "Budget account not found" });

    await account.softDelete();
    res.status(200).json({ message: "Budget account soft deleted" });
  } catch (error) {
    res.status(500).json({ message: "Internal server error", error });
  }
};