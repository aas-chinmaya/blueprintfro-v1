const SlotMaster = require('../../Model/Master/Slot');

// Create new slot with auto-increment slotNo
exports.createSlot = async (req, res) => {
  const { startTime, endTime, shift } = req.body;

  try {
    // Get the current max slotNo
    const lastSlot = await SlotMaster.findOne().sort({ slotNo: -1 });
    const nextSlotNo = lastSlot ? lastSlot.slotNo + 1 : 1;

    const newSlot = new SlotMaster({
      slotNo: nextSlotNo,
      startTime,
      endTime,
      shift
    });

    await newSlot.save();

    res.status(201).json({
      message: 'Slot created successfully',
      data: newSlot
    });
  } catch (err) {
    res.status(500).json({
      message: 'Failed to create slot',
      error: err.message
    });
  }
};

// Get all slots
exports.getAllSlots = async (req, res) => {
  try {
    const slots = await SlotMaster.find().sort({ slotNo: 1 });
    res.status(200).json({
      message: 'Slots fetched successfully',
      count: slots.length,
      data: slots
    });
  } catch (err) {
    res.status(500).json({
      message: 'Failed to fetch slots',
      error: err.message
    });
  }
};

// Delete slot by slotNo
exports.deleteSlot = async (req, res) => {
  const { slotNo } = req.params;

  try {
    const result = await SlotMaster.findOneAndDelete({ slotNo: Number(slotNo) });

    if (!result) {
      return res.status(404).json({ message: 'Slot not found' });
    }

    res.status(200).json({
      message: 'Slot deleted successfully',
      deleted: result
    });
  } catch (err) {
    res.status(500).json({
      message: 'Failed to delete slot',
      error: err.message
    });
  }
};
