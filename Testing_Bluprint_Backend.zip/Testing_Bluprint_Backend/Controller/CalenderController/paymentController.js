



const razorpay = require("../../services/razorpay");
const PaymentStatus = require("../../Model/CalenderModel/paymentModel");
const { sendEmail } = require("../../middlewares/nodemailer");
const Contact = require('../../Model/ContactModel/Contact');



 
exports.createPaymentLink = async (req, res) => {
  try {
    const { contactId, amount } = req.body
 
    if (!contactId || !amount) {
      return res.status(400).json({ message: 'contactId and amount are required.' })
    }
 
    //  Get contact details from DB
    const contact = await Contact.findOne({ contactId })
    if (!contact || !contact.email) {
      return res.status(404).json({ message: ' Contact not found or missing email.' })
    }
 
    const contactEmail = contact.email
    const fullName = contact.fullName || contactId
 
    console.log(' Sending to:', contactEmail)
 
    //  Create Razorpay payment link
    let response
    try {
      response = await razorpay.paymentLink.create({
        amount: amount * 100, // in paise
        currency: 'INR',
        description: 'Service Payment',
        customer: {
          name: fullName,
          email: contactEmail
        },
        notify: {
          sms: true,
          email: true
        },
        notes: { contactId },
        callback_url: 'https://bluapi.aas.technology/api/razorpay-webhook',
        callback_method: 'get'
      })
    } catch (razorErr) {
      console.error(' Razorpay Error:', razorErr)
      return res.status(500).json({
        message: ' Failed to create Razorpay payment link',
        error: razorErr.error || razorErr.message
      })
    }
 
    if (!response || !response.short_url) {
      return res.status(500).json({ message: 'Invalid Razorpay response (no short_url)' })
    }
 
    const shortUrl = response.short_url
 
    //  Save to PaymentStatus model
    const paymentStatus = new PaymentStatus({
      contactId,
      contactEmail,
      amount,
      paymentLink: shortUrl,
      status: 'unpaid',
      statusCode: response.status, // created / pending / paid
      paymentId: response.id
    })
 
    await paymentStatus.save()
 
    //  Your frontend payment page URL
    // const userPaymentPageUrl = `http://localhost:3000/payment?contactId=${contactId}`||`https://blu.aas.technology/payment?contactId=${contactId}`
      const userPaymentPageUrl = `https://blu.aas.technology/payment?contactId=${contactId}`;
 
    // Send email using Microsoft Graph
    const subject = ' Your Payment Link'
    const body = `
      <p>Dear ${fullName},</p>
      <p>Your free meeting quota is over. To proceed, please complete the payment:</p>
      <p><a href="${userPaymentPageUrl}" style="padding: 10px 20px; background-color: #007bff; color: #fff; text-decoration: none; border-radius: 5px;">Pay Now</a></p>
      <p>If the button above doesn’t work, open this link manually:</p>
      <p>Thank you,<br/>AAS Information Technology</p>
    `
 
    console.log('Sending payment email to:', contactEmail)
    await sendEmail(subject, body, contactEmail)
 
    res.status(200).json({
      message: ' Payment link created and email sent successfully',
      paymentLink: userPaymentPageUrl // this is the frontend link
    })
  } catch (error) {
    console.error(' Error in createPaymentLink:', error)
    res.status(500).json({
      message: ' Server Error',
      error: error.message || 'Unknown error'
    })
  }
}
 




exports.updatePaymentStatusCode = async (req, res) => {
  try {
    const { contactId, statusCode } = req.body;

    if (!contactId || !statusCode) {
      return res.status(400).json({ message: " contactId and statusCode are required." });
    }

    const updated = await PaymentStatus.findOneAndUpdate(
      { contactId },
      {
        $set: {
          status: "paid",      // Only changing status
          statusCode: statusCode //  Save this too (optional)
        }
      },
      {
        new: true
      }
    );

    if (!updated) {
      return res.status(404).json({ message: " No record found for the provided contactId." });
    }

    res.status(200).json({
      message: "Payment status updated to 'paid'.",
      data: updated,
    });

  } catch (error) {
    console.error("Error updating payment status:", error);
    res.status(500).json({ message: "Internal Server Error." });
  }
};



exports.getPaidStatusByContactId = async (req, res) => {
  try {
    const { contactId } = req.params;

    if (!contactId) {
      return res.status(400).json({ message: ' contactId is required in URL params.' });
    }

    const paidRecords = await PaymentStatus.find({ contactId, status: 'paid' });

    if (paidRecords.length === 0) {
      return res.status(404).json({ message: ' No paid records found for this contactId.' });
    }

    res.status(200).json({
      message: ` Found ${paidRecords.length} paid record(s) for contactId: ${contactId}`,
      data: paidRecords
    });
  } catch (error) {
    console.error(' Error fetching paid status:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};





exports.getPaymentLinkByContactId = async (req, res) => {
  try {
    const { contactId } = req.params;

    if (!contactId) {
      return res.status(400).json({
        message: ' contactId is required in URL params.'
      });
    }

    const paymentRecord = await PaymentStatus.find({ contactId })
      .sort({ createdAt: 1 }) // ascending order → earliest record first
      .limit(1);

    if (!paymentRecord || paymentRecord.length === 0) {
      return res.status(404).json({
        message: 'No payment record found for the provided contactId.'
      });
    }

    const record = paymentRecord[0];

    res.status(200).json({
      message: ' Payment record found',
      data: {
        _id: record._id,
        contactId: record.contactId,
        contactEmail: record.contactEmail,
        amount: record.amount,
        paymentLink: record.paymentLink,
        status: record.status,
        statusCode: record.statusCode,
        paymentId: record.paymentId,
        createdAt: record.createdAt
      }
    });
  } catch (error) {
    console.error(' Error fetching payment link:', error);
    res.status(500).json({
      message: 'Server Error',
      error: error.message
    });
  }
};






exports.getPaymentDetailsFromRazorpay = async (req, res) => {
  try {
    const { paymentId } = req.params;

    if (!paymentId) {
      return res.status(400).json({ message: "paymentId is required in URL params." });
    }

    // Fetch payment details directly from Razorpay
    const razorpayResponse = await razorpay.payments.fetch(paymentId);

    if (!razorpayResponse) {
      return res.status(404).json({ message: "No details found for the given paymentId." });
    }

    // You can log or store this data if needed
    console.log(" Razorpay Payment Data:", razorpayResponse);

    res.status(200).json({
      message: "Payment details fetched from Razorpay successfully.",
      data: {
        id: razorpayResponse.id,
        entity: razorpayResponse.entity,
        amount: razorpayResponse.amount / 100, // convert to INR
        currency: razorpayResponse.currency,
        status: razorpayResponse.status, // created, authorized, captured, failed, etc.
        method: razorpayResponse.method,
        email: razorpayResponse.email,
        contact: razorpayResponse.contact,
        fee: razorpayResponse.fee,
        tax: razorpayResponse.tax,
        captured: razorpayResponse.captured,
        created_at: new Date(razorpayResponse.created_at * 1000), // convert UNIX timestamp
      }
    });

  } catch (error) {
    console.error(" Error fetching payment from Razorpay:", error);
    res.status(500).json({
      message: "Failed to fetch payment details from Razorpay.",
      error: error.message || "Unknown error"
    });
  }
};



exports.updatePaymentStatusByPaymentId = async (req, res) => {
  try {
    const { paymentId } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ message: "Status is required" });
    }

    const payment = await PaymentStatus.findOneAndUpdate(
      { paymentId: paymentId },
      { $set: { status: status } },
      { new: true }
    );

    if (!payment) {
      return res.status(404).json({ message: "Payment not found" });
    }

    return res.status(200).json({
      message: "Payment status updated successfully",
      data: payment,
    });
  } catch (error) {
    console.error("Error updating payment status:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};