// import mongoose from "mongoose";
// import shortid from "shortid";

// const { Schema, model,Types } = mongoose;

// // ===============================
// //  Transaction Schema
// // ===============================
// const TransactionSchema = new Schema(
//   {
//     type: {
//       type: String,
//       enum: ["credit", "debit"], // credit = add funds, debit = spend funds
//       required: true,
//     },
//     category: { type: String, required: true }, // e.g. HR, Marketing, Finance
//     amount: { type: Number, required: true },
//     by: { type: String,  required: true },
//     timestamp: { type: Date, default: Date.now },
//     isDeleted: { type: Boolean, default: false },
//   },
//   { _id: true }
// );



// // ===============================
// // Main Budget Account Schema
// // ===============================
// const BudgetAccountSchema = new Schema({
//   accountId: { type: String, unique: true, index: true },
//   projectId: { type: Types.ObjectId, ref: "Project", required: true },

//   transactions: [TransactionSchema],

//   // Persisted totals
//   totalCredit: { type: Number, default: 0 },
//   totalSpent: { type: Number, default: 0 },
//   availableBalance: { type: Number, default: 0 },
//   closingBalance: { type: Number, default: 0 },
//   initialAmount: { type: Number, default: 0 },

//   createdAt: { type: Date, default: Date.now },
//   updatedAt: { type: Date, default: Date.now },
//   isDeleted: { type: Boolean, default: false },
// });
// // Pre-save hook: generate accountId if missing
// BudgetAccountSchema.pre("save", function (next) {
//   if (!this.accountId) {
//     const projPrefix = this.projectId.toString().slice(-5).toUpperCase();
//     this.accountId = `ACC-${projPrefix}-${shortid.generate()}`;
//   }
//   this.updatedAt = new Date();
//   this.updateTotals(); // Ensure totals are updated before saving
//   next();
// });

// // Method to recalculate totals
// BudgetAccountSchema.methods.updateTotals = function () {
//   let totalCredit = 0;
//   let totalSpent = 0;

//   this.transactions.forEach(txn => {
//     if (txn.type === "credit") totalCredit += txn.amount || 0;
//     if (txn.type === "debit") totalSpent += txn.amount || 0;
//   });

//   this.totalCredit = totalCredit;
//   this.totalSpent = totalSpent;
//   this.availableBalance = totalCredit - totalSpent;
//   this.closingBalance = this.availableBalance;
// };

// // Method to add a transaction
// BudgetAccountSchema.methods.addTransaction = async function (txnData) {
//   this.transactions.push(txnData);
//   this.updateTotals();
//   this.updatedAt = new Date();
//   return await this.save();
// };

// // Method to remove a transaction by ID
// BudgetAccountSchema.methods.removeTransaction = async function (txnId) {
//   this.transactions = this.transactions.filter(txn => txn._id.toString() !== txnId.toString());
//   this.updateTotals();
//   this.updatedAt = new Date();
//   return await this.save();
// };

// // Central model
// const BudgetAccount = model("BudgetAccount", BudgetAccountSchema);

// export default BudgetAccount;

const mongoose = require('mongoose');
const shortid = require('shortid');

const { Schema, model, Types } = mongoose;

// ===============================
// Transaction Schema
// ===============================
const TransactionSchema = new Schema(
  {
    type: {
      type: String,
      enum: ['credit', 'debit'], // credit = add funds, debit = spend funds
      required: true,
    },
    category: { type: String, required: true }, // e.g. HR, Marketing, Finance
    amount: { type: Number, required: true },
    by: { type: String, required: true },
    timestamp: { type: Date, default: Date.now },
    isDeleted: { type: Boolean, default: false },
  },
  { _id: true }
);

// ===============================
// Main Budget Account Schema
// ===============================
const BudgetAccountSchema = new Schema({
  accountId: { type: String, unique: true, index: true },
 projectId: { type: String, required: true },

  transactions: [TransactionSchema],

  // Persisted totals
  initialAmount: { type: Number, default: 0 },
  totalCredit: { type: Number, default: 0 },
  totalSpent: { type: Number, default: 0 },
  availableBalance: { type: Number, default: 0 },
  closingBalance: { type: Number, default: 0 },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  isDeleted: { type: Boolean, default: false },
});

// Pre-save hook: generate accountId if missing
// BudgetAccountSchema.pre('save', function (next) {
//   if (!this.accountId) {
//     const projPrefix = this.projectId.toString().slice(-5).toUpperCase();
//     this.accountId = `ACC-${projPrefix}-${shortid.generate()}`;
//   }
//   this.updatedAt = new Date();
//   this.updateTotals(); // Ensure totals are updated before saving
//   next();
// });

BudgetAccountSchema.pre("save", async function (next) {
  try {
    // Only generate if accountId not already set
    if (!this.accountId) {
      // Extract project code (third part of projectId)
      // Example: AAS-IT-TES-001 → TES
      const parts = this.projectId.split("-");
      const projectCode = parts[2] ? parts[2].toUpperCase() : "GEN";
 
      // Find last account for same project code
      const lastAccount = await mongoose.model("BudgetAccount").findOne({
        accountId: { $regex: `^ACC-${projectCode}-` },
      }).sort({ createdAt: -1 });
 
      // Determine next sequence number
      let nextNumber = 1;
      if (lastAccount && lastAccount.accountId) {
        const match = lastAccount.accountId.match(/(\d{3})$/);
        if (match) nextNumber = parseInt(match[1]) + 1;
      }
 
      // Format number with leading zeros
      const formattedNumber = String(nextNumber).padStart(3, "0");
 
      // Build final account ID
      this.accountId = `ACC-PROC${projectCode}-${formattedNumber}`;
    }
 
    this.updatedAt = new Date();
    this.updateTotals();
    next();
  } catch (err) {
    console.error("Error generating accountId:", err);
    next(err);
  }
});

// Method to recalculate totals including initialAmount
BudgetAccountSchema.methods.updateTotals = function () {
  let totalCredit = this.initialAmount || 0;
  let totalSpent = 0;

  this.transactions.forEach((txn) => {
    if (txn.type === 'credit') totalCredit += txn.amount || 0;
    if (txn.type === 'debit') totalSpent += txn.amount || 0;
  });

  this.totalCredit = totalCredit;
  this.totalSpent = totalSpent;
  this.availableBalance = totalCredit - totalSpent;
  this.closingBalance = this.availableBalance;
};

// Method to add a transaction
BudgetAccountSchema.methods.addTransaction = async function (txnData) {
  this.transactions.push(txnData);
  this.updateTotals();
  this.updatedAt = new Date();
  return this.save();
};

// Method to remove a transaction by ID
BudgetAccountSchema.methods.removeTransaction = async function (txnId) {
  this.transactions = this.transactions.filter(
    (txn) => txn._id.toString() !== txnId.toString()
  );
  this.updateTotals();
  this.updatedAt = new Date();
  return this.save();
};

// Static method to create BudgetAccount with initialAmount
BudgetAccountSchema.statics.createAccount = async function (projectId, initialAmount = 0) {
  const existing = await this.findOne({ projectId, isDeleted: false });
  if (existing) throw new Error('Budget account already exists for this project');

  const account = new this({ projectId, initialAmount });
  return account.save();
};

module.exports = model('BudgetAccount', BudgetAccountSchema);
