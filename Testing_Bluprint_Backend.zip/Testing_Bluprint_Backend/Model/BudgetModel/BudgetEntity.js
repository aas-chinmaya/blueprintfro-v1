// // const mongoose = require("mongoose");

// // const budgetEntitySchema = new mongoose.Schema(
// //   {
// //     entityId: {
// //       type: String,
// //       unique: true,
// //       required: true,
// //     },
// //     accountId: {
// //       type: mongoose.Schema.Types.ObjectId,
// //       required: true,
// //       ref: "BudgetAccount",
// //     },
// //     categoryId: {
// //       type: mongoose.Schema.Types.ObjectId,
// //       required: true,
// //       ref: "BudgetCategory",
// //     },
// //     name: {
// //       type: String,
// //       required: true,
// //       trim: true,
// //     },
// //     costType: {
// //       type: String,
// //       required: true,
// //       enum: ["hourly", "fixed", "monthly", "one-time"],
// //       default: "fixed",
// //     },
// //     rate: {
// //       type: Number,
// //       required: true,
// //       min: 0,
// //     },
// //     totalUnits: {
// //       type: Number,
// //       default: 1,
// //       min: 0,
// //     },
// //     totalCost: {
// //       type: Number,
// //       required: true,
// //       min: 0,
// //     },
// //     currency: {
// //       type: String,
// //       default: "INR",
// //     },
// //     history: [
// //       {
// //         action: {
// //           type: String,
// //           enum: ["create", "update", "delete"],
// //           required: true,
// //         },
// //         changedBy: {
// //           type: mongoose.Schema.Types.ObjectId,
// //           ref: "User",
// //           required: true,
// //         },
// //         changedAt: { type: Date, default: Date.now },
// //         changes: { type: mongoose.Schema.Types.Mixed },
// //       },
// //     ],

// //     // ===== Soft Delete =====
// //     isActive: { type: Boolean, default: true },
// //     isDeleted: { type: Boolean, default: false },

// //     // ===== Metadata =====
// //     createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
// //     createdByName: { type: String },
// //     createdByRole: { type: String },
// //     editedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
// //     editedByName: { type: String },
// //     editedByRole: { type: String },
// //   },
// //   {
// //     timestamps: {
// //       currentTime: () => {
// //         const now = new Date();
// //         const istOffset = 5.5 * 60 * 60 * 1000; // Convert to IST
// //         return new Date(now.getTime() + istOffset);
// //       },
// //     },
// //   }
// // );

// // // ================================
// // // Middleware to auto-generate entityId
// // // ================================
// // budgetEntitySchema.pre("validate", async function (next) {
// //   if (!this.entityId) {
// //     const count = await mongoose
// //       .model("BudgetEntity")
// //       .countDocuments({ categoryId: this.categoryId });

// //     const catCode = this.categoryId.toString().slice(-4).toUpperCase();
// //     this.entityId = `ENT${count + 1}`;
// //   }
// //   next();
// // });

// // // ================================
// // // Middleware to update category entityIds
// // // ================================
// // budgetEntitySchema.post("save", async function (doc, next) {
// //   try {
// //     await mongoose.model("BudgetCategory").findByIdAndUpdate(doc.categoryId, {
// //       $addToSet: { entityIds: doc._id },
// //     });
// //     next();
// //   } catch (err) {
// //     next(err);
// //   }
// // });

// // module.exports = mongoose.model("BudgetEntity", budgetEntitySchema);


// const mongoose = require("mongoose");

// const budgetEntitySchema = new mongoose.Schema(
//   {
//     entityId: {
//       type: String,
//       unique: true,
  
//     },
//     accountId: {
//       type: String,
//       required: true,
//       ref: "BudgetAccount",
//     },
//     categoryId: {
//       type: String,
//       ref: "BudgetCategory",
//     },
//     name: {
//       type: String,
//       required: true,
//       trim: true,
//     },
//     costType: {
//       type: String,
//       required: true,
//       enum: ["Hourly", "Fixed", "Quantity"],
//       default: "Fixed",
//     },
//     rate: {
//       type: Number,
      
//       min: 0,
//     },
//     totalUnits: {
//       type: Number,
//       default: 1,
//       min: 0,
//     },
//     totalCost: {
//       type: Number,
     
//       min: 0,
//     },
//     currency: {
//       type: String,
//       default: "INR",
//     },
//     history: [
//       {
//         action: {
//           type: String,
//           enum: ["create", "update", "delete"],
//         },
//         changedBy: {
//           type: String,
       
//         },
//         changedAt: { type: Date, default: Date.now },
//         changes: { type: String },
//       },
//     ],

//     // ===== Soft Delete =====
//     isActive: { type: Boolean, default: true },
//     isDeleted: { type: Boolean, default: false },


//   },
//   {
//     timestamps: {
//       currentTime: () => {
//         const now = new Date();
//         const istOffset = 5.5 * 60 * 60 * 1000; // Convert to IST
//         return new Date(now.getTime() + istOffset);
//       },
//     },
//   }
// );

// // ================================
// // Middleware to auto-generate entityId
// // ================================
// budgetEntitySchema.pre("save", async function (next) {
//   if (!this.entityId) {
//     try {
//       if (!this.categoryId) {
//         return next(new Error("categoryId is required to generate entityId"));
//       }

//       const count = await mongoose
//         .model("BudgetEntity")
//         .countDocuments({ categoryId: this.categoryId });

//       const catCode = this.categoryId.toString().slice(-4).toUpperCase();
//       this.entityId = `ENT-${count + 1}`;
//     } catch (err) {
//       return next(err);
//     }
//   }
//   next();
// });

// // ================================
// // Middleware to update category entityIds
// // ================================
// budgetEntitySchema.post("save", async function (doc, next) {
//   try {
//     await mongoose.model("BudgetCategory").findByIdAndUpdate(doc.categoryId, {
//       $addToSet: { entityIds: doc._id },
//     });
//     next();
//   } catch (err) {
//     next(err);
//   }
// });

// module.exports = mongoose.model("BudgetEntity", budgetEntitySchema);
const mongoose = require("mongoose");

const budgetEntitySchema = new mongoose.Schema(
  {
    entityId: {
      type: String,
      unique: true,
      trim: true,
    },
    accountId: {
      type: String,
      required: true, // e.g., "ACC-001"
      ref: "BudgetAccount",
      trim: true,
    },
    categoryId: {
      type: String, // e.g., "CAT-001"
      ref: "BudgetCategory",
      trim: true,
      required: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    costType: {
      type: String,
      required: true,
      enum: ["Hourly", "Fixed", "Quantity"],
      default: "Fixed",
    },
    rate: {
      type: Number,
      min: 0,
    },
    totalUnits: {
      type: Number,
      default: 1,
      min: 0,
    },
    totalCost: {
      type: Number,
      min: 0,
    },
    currency: {
      type: String,
      default: "INR",
      trim: true,
    },
    history: [
      {
        action: {
          type: String,
          enum: ["create", "update", "delete"],
        },
        changedBy: { type: String },
        changedAt: { type: Date, default: Date.now },
        changes: { type: String },
      },
    ],
    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  {
    timestamps: {
      currentTime: () => {
        const now = new Date();
        const istOffset = 5.5 * 60 * 60 * 1000;
        return new Date(now.getTime() + istOffset);
      },
    },
  }
);

// ================================
// Auto-generate entityId
// ================================
budgetEntitySchema.pre("save", async function (next) {
  if (!this.entityId) {
    try {
      const count = await mongoose
        .model("BudgetEntity")
        .countDocuments({ categoryId: this.categoryId });

      const categoryCode = this.categoryId.slice(-4).toUpperCase();
      this.entityId = `ENT-${categoryCode}-${count + 1}`;
    } catch (err) {
      return next(err);
    }
  }
  next();
});

// ================================
// Update BudgetCategory after entity creation
// ================================
budgetEntitySchema.post("save", async function (doc, next) {
  try {
    await mongoose
      .model("BudgetCategory")
      .updateOne(
        { categoryId: doc.categoryId },
        { $addToSet: { entityIds: doc.entityId } }
      );
    next();
  } catch (err) {
    next(err);
  }
});

module.exports = mongoose.model("BudgetEntity", budgetEntitySchema);
