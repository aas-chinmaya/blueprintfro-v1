
const mongoose = require('mongoose');
 
const ProjectmomSchema = new mongoose.Schema({
  momId: { type: String },
  projectId: { type: String },
  projectName:{type: String},
  date: { type: String },
  time: { type: String },
  agenda: { type: String },
  meetingMode: { type: String },
   meetingDate: { type: String },  
  duration: { type: String },
  attendees: [{ type: String }],
  summary: { type: String },
  notes: { type: String },
  
  signature: { type: String },
  isDeleted: { type: Boolean, default: false },
  status: {
    type: String,
    enum: ['draft', 'final'],
    default: 'final'
  },
  createdBy: { type: String },
   pdf: Buffer,
  pdfUrl: String
}, 


{ timestamps: true });
 
module.exports = mongoose.model('ProjectMom', ProjectmomSchema);


