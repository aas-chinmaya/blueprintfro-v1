// const express = require("express");
// const router = express.Router();
// const multer = require("multer");
// const path = require("path");
// const validateToken=require("../../middlewares/authMiddleware");
// const { viewProfileImage,uploadProfileImage,   checkToken,getUserByEmailFromCookie, getAllHRMSEmployees ,fetchAllUsers,sendOtpForLogin,verifyLoginOTP,getUserByEmail, logout,logoutAllDevices,  } = require("../../Controller/HrmsController/HrmsController");
// // Multer config for storing images
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, "uploads/profiles/"); // folder for profile images
//   },
//   filename: function (req, file, cb) {
//     cb(null, Date.now() + path.extname(file.originalname)); // unique filename
//   },
// });
 
// const upload = multer({ storage: storage });
// router.get("/employees", getAllHRMSEmployees);
// router.get("/fetchAllUsers",fetchAllUsers);

// router.post("/login", sendOtpForLogin);
// router.post("/verifyOtp", verifyLoginOTP);
// router.get("/getUserByEmail/:email",getUserByEmail);
// router.post("/logout",logout);
// router.post("/logoutAllDevices",logoutAllDevices);

// router.get("/user/profile", getUserByEmailFromCookie);
// router.post('/checkCookies', checkToken);
// router.post("/upload/:employeeID", upload.single("image"), uploadProfileImage);
// router.get("/view/:employeeId", viewProfileImage);
// // router.get('/refreshToken',refreshAccessToken)
// module.exports = router;
const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs"); // to check/create directories
const validateToken = require("../../middlewares/authMiddleware");

const {
  viewProfileImage,
  uploadProfileImage,
  checkToken,
  getUserByEmailFromCookie,
  getAllHRMSEmployees,
  fetchAllUsers,
  sendOtpForLogin,
  verifyLoginOTP,
  getUserByEmail,
  logout,
  logoutAllDevices,
} = require("../../Controller/HrmsController/HrmsController");


const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const basePath = path.join(process.cwd(), "uploads", "profiles");

    // Create the folder if it doesn't exist
    if (!fs.existsSync(basePath)) {
      fs.mkdirSync(basePath, { recursive: true });
    }

    cb(null, basePath);
  },
  filename: function (req, file, cb) {
    // Use timestamp + original file extension
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

// const upload = multer({ storage: storage });


const upload = multer({ storage: storage });
// Routes
router.get("/employees", getAllHRMSEmployees);
router.get("/fetchAllUsers", fetchAllUsers);

router.post("/login", sendOtpForLogin);
router.post("/verifyOtp", verifyLoginOTP);
router.get("/getUserByEmail/:email", getUserByEmail);
router.post("/logout", logout);
router.post("/logoutAllDevices", logoutAllDevices);

router.get("/user/profile", getUserByEmailFromCookie);
router.post("/checkCookies", checkToken);

// Upload & View profile image
router.post(
  "/upload/:employeeID",
  upload.single("image"),
  uploadProfileImage
);

router.get("/view/:employeeId", viewProfileImage);

module.exports = router;
