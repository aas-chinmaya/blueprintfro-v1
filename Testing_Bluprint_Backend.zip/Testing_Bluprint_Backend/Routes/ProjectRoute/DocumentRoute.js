// const express = require("express");
// const router = express.Router();
// const multer = require("multer");
// const path = require("path");
// const fs = require('fs');
// const documentController = require("../../Controller/ProjectController/DocumentController");

// // Multer storage config (disk storage, saves files in /uploads folder)
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, "uploads/"); // ensure this folder exists
//   },
//   filename: function (req, file, cb) {
//     const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
//     cb(null, uniqueSuffix + path.extname(file.originalname));
//   },
// });


// const upload = multer({ storage });

// // Upload document (field name MUST match Postman key → "document")
// router.post(
//   "/uploadprojectdocument/:projectId",
//   upload.single("document"),
//   documentController.uploadDocument
// );

// // Get all documents by projectId
// router.get(
//   "/getalldocuments/:projectId",
//   documentController.getDocumentsByProject
// );

// // Soft delete document
// router.delete(
//   "/softdeletedocument/:documentId",
//   documentController.softDeleteDocument
// );

// router.get("/view/:documentId", documentController.viewDocument);
 
 


// module.exports = router;




const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const documentController = require("../../Controller/ProjectController/DocumentController");

// Ensure uploads/profiles folder exists
// const UPLOAD_FOLDER = "uploads/profiles";

// if (!fs.existsSync(UPLOAD_FOLDER)) {
//   fs.mkdirSync(UPLOAD_FOLDER, { recursive: true });
// }

// // Multer storage config
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     // ensure folder exists dynamically
//     if (!fs.existsSync(UPLOAD_FOLDER)) {
//       fs.mkdirSync(UPLOAD_FOLDER, { recursive: true });
//     }
//     cb(null, UPLOAD_FOLDER);
//   },
//   filename: function (req, file, cb) {
//     const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
//     cb(null, uniqueSuffix + path.extname(file.originalname));
//   },
// });

// const upload = multer({ storage });


// Ensure base uploads folder exists
const UPLOAD_FOLDER = path.join(process.cwd(), "uploads", "projects");

if (!fs.existsSync(UPLOAD_FOLDER)) {
  fs.mkdirSync(UPLOAD_FOLDER, { recursive: true });
}

// Multer storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Store all files directly in the base folder
    cb(null, UPLOAD_FOLDER);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

// Upload document (field name MUST match Postman key → "document")
router.post(
  "/uploadprojectdocument/:projectId",
  upload.single("document"),
  documentController.uploadDocument
);

// Get all documents by projectId
router.get(
  "/getalldocuments/:projectId",
  documentController.getDocumentsByProject
);

// Soft delete document
router.delete(
  "/softdeletedocument/:documentId",
  documentController.softDeleteDocument
);

// View a document
router.get("/view/:documentId", documentController.viewDocument);

module.exports = router;
