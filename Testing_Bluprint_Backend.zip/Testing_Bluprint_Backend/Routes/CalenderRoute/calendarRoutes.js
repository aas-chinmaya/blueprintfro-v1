

const express = require('express');
const router = express.Router();
const calendar = require('../../Controller/CalenderController/calendarController');


router.get('/getallmeetings', calendar.getAllMeetings);
router.get('/auth-url', calendar.getAuthUrl);
router.get('/oauth2callback', calendar.oauthCallback);
router.post('/create-meeting', calendar.createMeeting);
router.get('/meetings/upcoming/:email', calendar.getUpcomingMeetings);
router.post('/meeting/update', calendar.updateMeeting);
router.delete('/meeting/:email/:eventId', calendar.deleteMeeting);
router.get('/meetings/contact/:contactId', calendar.getMeetingsByContactId);
router.post("/createteammeeting", calendar.createTeamMeeting);


router.get('/meetings/project/:projectId', calendar.getMeetingsByProjectId);
module.exports = router;
