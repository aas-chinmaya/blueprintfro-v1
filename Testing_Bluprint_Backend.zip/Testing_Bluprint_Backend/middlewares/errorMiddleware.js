const logger = require('../utils/logfile'); 

// Error Handling Middleware
const logError = (err, req, res, next) => {
 
  logger.error('Error occurred: ' + err.message, logger.addMeta({
    url: req.originalUrl,
    method: req.method,
    statusCode: res.statusCode,
    stack: err.stack,
  }));

  
  res.status(500).json({ message:err.message });
  next();
};

module.exports = logError;
