// const nodemailer = require("nodemailer");

// // Set up the Nodemailer transport using environment variables
// const transporter = nodemailer.createTransport({
//   // host: process.env.MAIL_HOST,
//   // port: process.env.MAIL_PORT,
//   service: "gmail",
//   auth: {
//     user: 'arunak47.b@gmail.com',
//     pass: 'dhppstzo issv xshp',
//   },
// });

// module.exports = transporter;


const { Client } = require('@microsoft/microsoft-graph-client');
const { ClientSecretCredential } = require('@azure/identity');
const { isArray } = require('util');
require('isomorphic-fetch');
 
// Your app's credentials
const tenantId = '296a8ad9-383e-4412-9bcd-0f4f86e00a8c';
const clientId = 'a25bbd8f-9e41-4631-99b6-b38a2245805f';
const clientSecret = 'zkr8Q~_hKrg83CzYsGKTo9H.YIVhCRQRjr5TVaim';
const senderEmail = 'no-reply@aas.technology'; // Must be licensed mailbox
 
// Authenticate
const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
 
const graphClient = Client.initWithMiddleware({
  authProvider: {
    getAccessToken: async () => {
      const token = await credential.getToken('https://graph.microsoft.com/.default');
      return token.token;
    },
  },
});
 
 
exports.sendEmail = async (Subject, Body, ToRecipient, CcRecipients = []) => {
  let ToRecipients
  if(Array.isArray(ToRecipient)){
     ToRecipients=ToRecipient
  }else{
    ToRecipients=[ToRecipient]
  }
  const message = {
    subject: Subject,
    body: {
      contentType: 'HTML',
      content: Body,
    },
    toRecipients: ToRecipients.map(email => ({
      emailAddress: { address: email }
    })),
   
  };
 
  if (CcRecipients.length > 0) {
    message.ccRecipients = CcRecipients.map(email => ({
      emailAddress: { address: email }
    }));
  }
 
  const mail = {
    message,
    saveToSentItems: 'true',
  };
 
  try {
    await graphClient.api(`/users/${senderEmail}/sendMail`).post(mail);
    console.log('Email sent successfully');
  } catch (error) {
    console.error('Error sending email:', error);
  }
};
 