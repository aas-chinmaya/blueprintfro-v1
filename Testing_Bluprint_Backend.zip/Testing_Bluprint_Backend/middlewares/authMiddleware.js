

// // // const jwt = require('jsonwebtoken');
// // // const Session=require("../Model/HrmsModel/sessionModel");
// // // const { log } = require('winston');
 

// // // const validateToken = async (req, res, next) => {
// // //   try {
// // //     const token = req.cookies.token;
// // //     console.log(token);
    
    
// // //     if (!token) {
// // //       return res.status(401).json({ message: "Token not found." });
// // //     }

// // //     // Verify token
// // //     const decodedToken = jwt.verify(token, process.env.JWT_SECRET_KEY);
// // //     req.user = decodedToken;

// // //     // Check if session exists
// // //     // const session = await Session.findOne({
// // //     //   sessionToken: token,
// // //     //   userId: decodedToken.id,
// // //     // });

// // //     // if (!session) {
// // //     //   return res.status(401).json({ message: "Session expired. Please log in again." });
// // //     // }

// // //     // Proceed to next middleware
// // //     next();
// // //   } catch (error) {
// // //     console.log(error);
    

// // //     return res.status(403).json({
// // //       message: process.env.TOKEN_INVALID || "Invalid token. Please log in again.",
// // //     });
// // //   }
// // // };
 
// // // module.exports = validateToken;

// const jwt = require("jsonwebtoken");
// const connections = require("../Config/db");

 

// // const generateToken = (payload) => {
// //   return jwt.sign(payload, process.env.JWT_SECRET_KEY, { expiresIn: "1m" }); // access token 1 min
// // };


// // const validateToken = async (req, res, next) => {
// //   try {
// //     const accessToken = req.cookies.token;
// //     const refreshToken = req.cookies.refreshToken;

// //     if (!accessToken) {
// //       return res.status(401).json({ message: "Access token missing." });
// //     }

// //     try {
// //       const decoded = jwt.verify(accessToken, process.env.JWT_SECRET_KEY);
// //       req.user = decoded;
// //       return next();
// //     } catch (err) {
// //       if (err.name === "TokenExpiredError") {
// //         if (!refreshToken) {
// //           return res.status(401).json({ message: "Refresh token missing." });
// //         }

// //         try {
// //           const decodedRefresh = jwt.verify(refreshToken, process.env.JWT_SECRET_KEY);

// //           // Generate new access token with role
// //           const newAccessToken = generateToken({
// //             id: decodedRefresh.id,
// //             role: decodedRefresh.role
// //           });

// //           res.cookie("token", newAccessToken, {
// //             httpOnly: true,
// //             secure: true,
// //             sameSite: "None",
// //             path: "/",
// //             maxAge: 60 * 1000, // 1 min
// //           });

// //           req.user = decodedRefresh;
// //           return next();
// //         } catch (refreshErr) {
// //           return res.status(403).json({ message: "Invalid or expired refresh token." });
// //         }
// //       }

// //       return res.status(401).json({ message: "Invalid token. Please log in again." });
// //     }
// //   } catch (error) {
// //     console.error("Token validation error:", error);
// //     return res.status(500).json({ message: "Server error" });
// //   }
// // };

// const validateToken = async (req, res, next) => {
//   try {
//     const accessToken = req.cookies.token;
//     const refreshToken = req.cookies.refreshToken;

//     // If no access token, try using refresh token
//     if (!accessToken) {
//       if (!refreshToken) return res.status(401).json({ message: "No access or refresh token found." });

//       try {
//         const decodedRefresh = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET_KEY);

//         // Generate new access token automatically (without role)
//         const newAccessToken = generateToken({
//           id: decodedRefresh.id,
//         });

//         // Set new access token cookie
//         res.cookie("token", newAccessToken, {
//           httpOnly: true,
//           secure: true,
//           sameSite: "None",
//           path: "/",
//           maxAge: 60 * 1000, // 1 minute
//         });

//         req.user = decodedRefresh;
//         return next();
//       } catch (err) {
//         return res.status(403).json({ message: "Invalid or expired refresh token." });
//       }
//     }

//     try {
//       const decoded = jwt.verify(accessToken, process.env.JWT_SECRET_KEY);
//       req.user = decoded;
//       return next();
//     } catch (err) {
//       // Access token expired
//       if (err.name === "TokenExpiredError") {
//         if (!refreshToken) return res.status(401).json({ message: "Refresh token missing." });

//         try {
//           const decodedRefresh = jwt.verify(refreshToken, process.env.JWT_SECRET_KEY);

//           // Generate new access token automatically (without role)
//           const newAccessToken = generateToken({
//             id: decodedRefresh.id,
//           });

//           res.cookie("token", newAccessToken, {
//             httpOnly: true,
//             secure: true,
//             sameSite: "None",
//             path: "/",
//             maxAge: 60 * 1000, // 1 minute
//           });

//           req.user = decodedRefresh;
//           return next();
//         } catch (refreshErr) {
//           return res.status(403).json({ message: "Invalid or expired refresh token." });
//         }
//       }

//       return res.status(401).json({ message: "Invalid token. Please login again." });
//     }
//   } catch (error) {
//     console.error("Token validation error:", error);
//     return res.status(500).json({ message: "Server error" });
//   }
// };











// // const validateToken = async (req, res, next) => {
// //   try {
// //     const accessToken = req.cookies.token;
// //     const refreshToken = req.cookies.refreshToken;

// //     if (!accessToken) {
// //       return res.status(401).json({ message: "Access token missing." });
// //     }

// //     try {
// //       // Verify access token
// //       const decoded = jwt.verify(accessToken, process.env.JWT_SECRET_KEY);
// //       req.user = decoded;
// //       return next();
// //     } catch (err) {
// //       // Access token expired
// //       if (err.name === "TokenExpiredError") {
// //         if (!refreshToken) {
// //           return res.status(401).json({ message: "Refresh token missing." });
// //         }

// //         // Verify refresh token
// //         let decodedRefresh;
// //         try {
// //           decodedRefresh = jwt.verify(refreshToken, process.env.JWT_SECRET_KEY);
// //         } catch (refreshErr) {
// //           return res.status(403).json({ message: "Invalid or expired refresh token." });
// //         }

// //         // Generate new access token
// //         const newAccessToken = generateToken({ id: decodedRefresh.id, role: decodedRefresh.role });

// //         // Set new access token cookie
// //         res.cookie("token", newAccessToken, {
// //           httpOnly: true,
// //           secure: true,
// //           sameSite: "None",
// //           path: "/",
// //           maxAge: 24 * 60 * 60 * 1000, // 1 day
// //         });

// //         req.user = decodedRefresh; // attach payload
// //         return next();
// //       }

// //       // Other JWT errors
// //       return res.status(401).json({ message: "Invalid token. Please log in again." });
// //     }
// //   } catch (error) {
// //     console.error("Token validation error:", error);
// //     return res.status(500).json({ message: "Server error" });
// //   }
// // };

// module.exports = validateToken;

// // const jwt = require("jsonwebtoken");

// // // Generate new access token
// // const generateAccessToken = (payload) => {
// //   return jwt.sign(payload, process.env.JWT_ACCESS_SECRET, { expiresIn: "15m" });
// // };

// // const validateToken = (req, res, next) => {
// //   try {
// //     const accessToken = req.cookies.token;
// //     const refreshToken = req.cookies.refreshToken;

// //     if (!accessToken) return res.status(401).json({ message: "Access token missing." });

// //     try {
// //       // Verify access token
// //       const decoded = jwt.verify(accessToken, process.env.JWT_ACCESS_SECRET);
// //       req.user = decoded;
// //       return next();
// //     } catch (err) {
// //       // Access token expired
// //       if (err.name === "TokenExpiredError") {
// //         if (!refreshToken) return res.status(401).json({ message: "Refresh token missing." });

// //         // Verify refresh token
// //         let decodedRefresh;
// //         try {
// //           decodedRefresh = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
// //         } catch {
// //           return res.status(403).json({ message: "Invalid or expired refresh token." });
// //         }

// //         // Generate new access token
// //         const newAccessToken = generateAccessToken({ id: decodedRefresh.id, role: decodedRefresh.role });

// //         // Set new access token cookie
// //         res.cookie("token", newAccessToken, {
// //           httpOnly: true,
// //           secure: true,
// //           sameSite: "None",
// //           path: "/",
// //           maxAge: 15 * 60 * 1000, // 15 min
// //         });

// //         req.user = decodedRefresh; // attach payload
// //         return next();
// //       }

// //       // Other JWT errors
// //       return res.status(401).json({ message: "Invalid token. Please log in again." });
// //     }
// //   } catch (error) {
// //     console.error("Token validation error:", error);
// //     return res.status(500).json({ message: "Server error" });
// //   }
// // };

// // module.exports = validateToken;
const jwt = require("jsonwebtoken");
const connections = require("../Config/db");
const generateToken = (payload) => {
    return jwt.sign(payload, process.env.JWT_SECRET_KEY, { expiresIn: "15m" });
};
const validateToken = async (req, res, next) => {
  try {
    const accessToken = req.cookies.token;
    const refreshToken = req.cookies.refreshToken;
 
    // ---------------- Case 1: No Access Token ----------------
    if (!accessToken) {
      if (!refreshToken) {
        return res.status(401).json({ message: "No access or refresh token found." });
      }
 
      try {
        const decodedRefresh = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET_KEY);
 
        // Generate new access token
        const newAccessToken = generateToken({ id: decodedRefresh.id, role: decodedRefresh.role });
 
        // Set cookie with new access token
        res.cookie("token", newAccessToken, {
          httpOnly: true,
          secure: true,
          sameSite: "None",
          path: "/",
          maxAge: 24 * 60 * 60 * 1000, // 1 day
        });
 
        // Attach user info and new token to request
        req.user = decodedRefresh;
        req.accessToken = newAccessToken; // Optional, so handlers can use it
 
        return next();
      } catch (err) {
        return res.status(403).json({ message: "Invalid or expired refresh token." });
      }
    }
 
    // ---------------- Case 2: Access Token exists ----------------
    try {
      const decoded = jwt.verify(accessToken, process.env.JWT_SECRET_KEY);
      req.user = decoded;
      console.log("bfore refresh",req.user);
      req.accessToken = accessToken; // Original token
      console.log("bfore  access refresh1",req.accessToken);
      return next();
    } catch (err) {
      if (err.name === "TokenExpiredError") {
        // Access token expired → try refresh token
        if (!refreshToken) return res.status(401).json({ message: "Refresh token missing." });
 
        try {
          const decodedRefresh = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET_KEY);
 
          // Generate new access token
          const newAccessToken = generateToken({ id: decodedRefresh.id, role: decodedRefresh.role });
 
          // Replace cookie with new access token
          res.cookie("token", newAccessToken, {
            httpOnly: true,
            secure: true,
            sameSite: "None",
            path: "/",
            maxAge: 24 * 60 * 60 * 1000, // 1 day
          });
 
          // Attach user info and new token to request
          req.user = decodedRefresh;
          req.accessToken = newAccessToken;
          console.log("after refresh",req.user);
          console.log("after access  refresh",req.accessToken);
         
 
          return next(); // Current request continues
        } catch (refreshErr) {
          console.error("Refresh token verification error:", refreshErr);
          return res.status(403).json({ message: "Invalid or expired refresh token." });
        }
      }
 
      // Invalid token for other reasons
      return res.status(401).json({ message: "Invalid token. Please login again." });
    }
  } catch (error) {
    console.error("Token validation error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};

 module.exports = validateToken;
