const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const validateToken=require("../../middlewares/authMiddleware");
const { viewProfileImage,uploadProfileImage,   checkToken,getUserByEmailFromCookie, getAllHRMSEmployees ,fetchAllUsers,sendOtpForLogin,verifyLoginOTP,getUserByEmail, logout,logoutAllDevices,  } = require("../../Controller/HrmsController/HrmsController");
// Multer config for storing images
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/profiles/"); // folder for profile images
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname)); // unique filename
  },
});
 
const upload = multer({ storage: storage });
router.get("/employees", getAllHRMSEmployees);
router.get("/fetchAllUsers",fetchAllUsers);

router.post("/login", sendOtpForLogin);
router.post("/verifyOtp", verifyLoginOTP);
router.get("/getUserByEmail/:email",getUserByEmail);
router.post("/logout",logout);
router.post("/logoutAllDevices",logoutAllDevices);

router.get("/user/profile", getUserByEmailFromCookie);
router.post('/checkCookies', checkToken);
router.post("/upload/:employeeID", upload.single("image"), uploadProfileImage);
router.get("/view/:employeeId", viewProfileImage);
// router.get('/refreshToken',refreshAccessToken)
module.exports = router;
