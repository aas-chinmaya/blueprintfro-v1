// const Task = require('../../Model/TaskModel/Task');
// exports.createSubtask = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const { title, description, assignedTo, deadline } = req.body;

//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
//     if (!task) {
//       return res.status(404).json({ success: false, message: "Parent task not found" });
//     }

//     // Generate subtask_id based on number of existing subtasks
//     let nextId = task.subtasks ? task.subtasks.length + 1 : 1;
//     const subtask_id = `${taskId}-SubTask-${String(nextId).padStart(3, '0')}`;

//     const newSubtask = {
//       subtask_id,
//       title,
//       description,
//       assignedTo,
//       deadline
//     };

//     task.subtasks.push(newSubtask);
//     await task.save();

//     res.status(201).json({ success: true, subtask: newSubtask });
//   } catch (error) {
//     console.error("Error creating subtask:", error);
//     res.status(500).json({ success: false, message: "Error creating subtask", error: error.message });
//   }
// };



 
// const Task = require('../../Model/TaskModel/Task');
const Notification = require('../../Model/NotificationModel/notificationModel');
 const Task = require('../../Model/TaskModel/Task');
const Bug = require('../../Model/BugModel/Bug');
// const Notification = require('../../Model/NotificationModel/notificationModel');
const Team=require('../../Model/TeamModel/Team')
 
// Create Subtask
exports.createSubtask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const { title, description, assignedTo, priority, deadline } = req.body;
 
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: "Parent task not found" });
    }
 
    // Generate subtask_id
    let nextId = task.subtasks ? task.subtasks.length + 1 : 1;
    const subtask_id = `${taskId}-${String(nextId).padStart(3, '0')}`;
 
    const newSubtask = {
      subtask_id,
      title,
      description,
      assignedTo,
      priority,
      deadline,
      status: "Pending",
      reviewStatus: "N/A",
      createdAt: new Date()
    };
 
    task.subtasks.push(newSubtask);
 
    // Add to task history
    task.taskHistory.push({ action: "Subtask Created", timestamp: new Date() });
 
    await task.save();
 
    //  Send notification to the assigned user
    if (assignedTo) {
      const notification = new Notification({
        recipientId: assignedTo,
        message: `You have been assigned a new subtask "${title}" under task "${task.title}"`,
        link: `/tasks/${taskId}/${subtask_id}`
      });
      await notification.save();
    }
 
    res.status(201).json({ success: true, subtask: newSubtask });
  } catch (error) {
    console.error("Error creating subtask:", error);
    res.status(500).json({ success: false, message: "Error creating subtask", error: error.message });
  }
};
 
// View all subtasks of a task
// exports.getAllSubtasks = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
 
//     if (!task) return res.status(404).json({ success: false, message: "Task not found" });
 
//     const subtasks = task.subtasks.filter(st => !st.isDeleted);
//     res.json({ success: true, subtasks });
//   } catch (error) {
//     res.status(500).json({ success: false, message: "Error fetching subtasks", error: error.message });
//   }
// };
// exports.getAllSubtasks = async (req, res) => {
//   try {
//     const { taskId } = req.params;
 
//     const task = await Task.aggregate([
//       { $match: { task_id: taskId, isDeleted: false } },
//       {
//         $project: {
//           subtasks: {
//             $filter: {
//               input: "$subtasks",
//               as: "st",
//               cond: { $eq: ["$$st.isDeleted", false] }
//             }
//           }
//         }
//       }
//     ]);
 
//     if (!task || task.length === 0) {
//       return res.status(404).json({
//         success: false,
//         message: "Task not found",
//       });
//     }
 
//     const subtasks = task[0].subtasks;
 
//     return res.status(200).json({
//       success: true,
//       count: subtasks.length,
//       subtasks,
//     });
 
//   } catch (error) {
//     return res.status(500).json({
//       success: false,
//       message: "Error fetching subtasks",
//       error: error.message,
//     });
//   }
// };
 
 

exports.getAllSubtasks = async (req, res) => {
  try {
    const { taskId } = req.params;

    const task = await Task.findOne(
      { task_id: taskId, isDeleted: false },
      { subtasks: 1 } // select only subtasks
    );

    if (!task) {
      return res.status(404).json({
        success: false,
        message: "Task not found",
      });
    }

    // Filter out deleted subtasks
    let subtasks = task.subtasks.filter(st => st.isDeleted === false);

    // Sort by createdAt descending (latest first)
    subtasks.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    return res.status(200).json({
      success: true,
      count: subtasks.length,
      subtasks,
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Error fetching subtasks",
      error: error.message,
    });
  }
};








 
 
// View subtask by ID
// exports.getSubtaskById = async (req, res) => {
//   try {
//     const { taskId, subtaskId } = req.params;
//     const task = await Task.findOne({ task_id: taskId, isDeleted: false });
 
//     if (!task) return res.status(404).json({ success: false, message: "Task not found" });
 
//     const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
//     if (!subtask) return res.status(404).json({ success: false, message: "Subtask not found" });
 
//     res.json({ success: true, subtask });
//   } catch (error) {
//     res.status(500).json({ success: false, message: "Error fetching subtask", error: error.message });
//   }
// };
exports.getSubtaskById = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;

    // 1. Find the parent task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: "Task not found" });
    }

    // 2. Find the subtask within the task
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
    if (!subtask) {
      return res.status(404).json({ success: false, message: "Subtask not found" });
    }

    // 3. Get projectId from task and fetch teams
    const projectId = task.projectId;
    const teams = await Team.find({ projectId, isDeleted: false });

    let assignedMember = null;
    let assignedTeam = null;

    // 4. Find the team containing the assigned member
    for (const team of teams) {
      const member = team.teamMembers.find(m => m.memberId === subtask.assignedTo);
      if (member) {
        assignedMember = member;
        assignedTeam = team;
        break;
      }
    }

    // 5. Build assignedToDetails
    const assignedToDetails = assignedMember
      ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role,
        }
      : null;

    // 6. Fetch assignedBy details from parent task
    const assignedBy = task.assignedBy
      ? { assignedBy: task.assignedBy }  // If needed, you can also fetch full member details from Team
      : null;

    // 7. Fetch bugs related to this subtask (subtaskRef = subtask.subtask_id)
    const bugs = await Bug.find({ subtaskRef: subtask.subtask_id }).sort({ createdAt: -1 });

    // 8. Enriched subtask object
    const enrichedSubtask = {
      ...subtask.toObject(),
      teamLeadId: assignedTeam ? assignedTeam.teamLeadId : null,
      assignedToDetails,
      assignedBy,
      bugs, // only bugs related to this subtask
    };

    res.status(200).json({ success: true, subtask: enrichedSubtask });

  } catch (error) {
    console.error('Error in getSubtaskById:', error);
    res.status(500).json({ success: false, message: "Failed to get subtask", error: error.message });
  }
};


 
// Edit subtask
exports.editSubtask = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
    const updates = req.body;
 
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) return res.status(404).json({ success: false, message: "Task not found" });
 
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
    if (!subtask) return res.status(404).json({ success: false, message: "Subtask not found" });
 
    Object.assign(subtask, updates, { updatedAt: new Date() });
 
    // Add history
    task.taskHistory.push({ action: "Subtask Updated", timestamp: new Date() });
 
    await task.save();
 
    res.json({ success: true, subtask });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error updating subtask", error: error.message });
  }
};
 
// Soft delete subtask
exports.softDeleteSubtask = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
 
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) return res.status(404).json({ success: false, message: "Task not found" });
 
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId);
    if (!subtask) return res.status(404).json({ success: false, message: "Subtask not found" });
 
    subtask.isDeleted = true;
 
    // Add history
    task.taskHistory.push({ action: "Subtask Deleted", timestamp: new Date() });
 
    await task.save();
 
    res.json({ success: true, message: "Subtask deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error deleting subtask", error: error.message });
  }
};
 
 
// Update Subtask Status by subtask_id
exports.updateSubtaskStatusById = async (req, res) => {
  try {
    const { taskId, subtaskId } = req.params;
    const { status } = req.body;
 
    // Allowed statuses
    const validStatuses = ['Pending', 'In Progress', 'Completed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be Pending, In Progress, or Completed.',
      });
    }
 
    // Find parent task
    const task = await Task.findOne({ task_id: taskId, isDeleted: false });
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found' });
    }
 
    // Find subtask inside task
    const subtask = task.subtasks.find(st => st.subtask_id === subtaskId && !st.isDeleted);
    if (!subtask) {
      return res.status(404).json({ success: false, message: 'Subtask not found' });
    }
 
    // Update subtask status
    subtask.status = status;
 
    // If subtask is marked completed, set completedAt
    if (status === 'Completed' && !subtask.completedAt) {
      subtask.completedAt = new Date();
 
      if (subtask.deadline && new Date() > new Date(subtask.deadline)) {
        subtask.isLate = true;
      }
    }
 
    // Add history entry
    task.taskHistory.push({ action: `Subtask ${status}`, timestamp: new Date() });
 
    await task.save();
 
    //  Create notification for assigned user
    if (subtask.assignedTo) {
      const notification = new Notification({
        recipientId: subtask.assignedTo,
        message: `Subtask "${subtask.title}" is now marked as ${status}`,
        link: `/tasks/${taskId}/subtasks/${subtaskId}` // optional frontend link
      });
      await notification.save();
    }
 
    res.status(200).json({
      success: true,
      message: 'Subtask status updated successfully',
      subtask,
    });
  } catch (err) {
    console.error('Error updating subtask status:', err);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};


// Fetch all tasks by assignedTo
// exports.getTasksByAssignedTo = async (req, res) => {
//   try {
//     const { assignedTo } = req.params;

//     if (!assignedTo) {
//       return res.status(400).json({ message: "assignedTo is required" });
//     }

//     const tasks = await Task.find({ assignedTo, isDeleted: false })
//       .sort({ createdAt: -1 })
//       .lean();

//     if (!tasks || tasks.length === 0) {
//       return res.status(404).json({ message: "No tasks found for this user" });
//     }

//     res.status(200).json({
//       success: true,
//       count: tasks.length,
//       tasks,
//     });
//   } catch (error) {
//     console.error("Error fetching tasks by assignedTo:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server error",
//       error: error.message,
//     });
//   }
// };


// exports.getTasksByAssignedTo = async (req, res) => {
//   try {
//     const { assignedTo } = req.params;

//     if (!assignedTo) {
//       return res.status(400).json({ message: "assignedTo is required" });
//     }

//     // Use aggregation to get only matching subtasks
//     const tasks = await Task.aggregate([
//       { $match: { "subtasks.assignedTo": assignedTo, isDeleted: false } },
//       { $unwind: "$subtasks" },
//       { $match: { "subtasks.assignedTo": assignedTo, "subtasks.isDeleted": false } },
//       {
//         $project: {
//           _id: 0,
//           subtask: "$subtasks",
//         },
//       },
//       { $sort: { "subtask.createdAt": -1 } },
//     ]);

//     if (!tasks || tasks.length === 0) {
//       return res.status(404).json({ message: "No subtasks found for this user" });
//     }

//     res.status(200).json({
//       success: true,
//       count: tasks.length,
//       subtasks: tasks.map(t => t.subtask),
//     });
//   } catch (error) {
//     console.error("Error fetching subtasks by assignedTo:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server error",
//       error: error.message,
//     });
//   }
// };


//  Fetch only subtasks assigned to a user (with task_id & projectName)
exports.getTasksByAssignedTo = async (req, res) => {
  try {
    const { assignedTo } = req.params;

    if (!assignedTo) {
      return res.status(400).json({ message: "assignedTo is required" });
    }

    // Use aggregation to get only matching subtasks + parent info
    const tasks = await Task.aggregate([
      { $match: { "subtasks.assignedTo": assignedTo, isDeleted: false } },
      { $unwind: "$subtasks" },
      { 
        $match: { 
          "subtasks.assignedTo": assignedTo, 
          "subtasks.isDeleted": false 
        } 
      },
      {
        $project: {
          _id: 0,
          task_id: 1,
          projectName: 1,
          projectId: 1,
          subtask: "$subtasks",
        },
      },
      { $sort: { "subtask.createdAt": -1 } },
    ]);

    if (!tasks || tasks.length === 0) {
      return res.status(404).json({ message: "No subtasks found for this user" });
    }

    res.status(200).json({
      success: true,
      count: tasks.length,
      subtasks: tasks.map(t => ({
        task_id: t.task_id,
        projectName: t.projectName,
        projectId: t.projectId,
        ...t.subtask,
      })),
    });
  } catch (error) {
    console.error("Error fetching subtasks by assignedTo:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};