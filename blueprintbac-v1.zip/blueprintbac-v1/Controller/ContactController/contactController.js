


const Contact = require('../../Model/ContactModel/Contact');
const { sendEmail } = require('../../middlewares/nodemailer');
 
// Helper function to get month name
const getMonthName = (date) => {
  return date.toLocaleString('en-US', { month: 'long' }).toLowerCase();
};
 

  exports.createContact = async (req, res) => {
  try {
    const {
      fullName,
      email,
      phone,
      companyName,
      designation,
      industry,
      location,
      Companylocation,
      serviceInterest,
      referralSource,
      message
    } = req.body;
 
    const now = new Date();
    const month = getMonthName(now); // e.g., 'july'
    const year = now.getFullYear().toString().slice(-2); // e.g., '25'
 
    const lastContact = await Contact.findOne({
      contactId: new RegExp(`^CId-${month}-${year}-\\d{3}$`, 'i')
    }).sort({ createdAt: -1 });
 
    let sequence = 1;
    if (lastContact && lastContact.contactId) {
      const parts = lastContact.contactId.split('-');
      const lastSeq = parseInt(parts[3], 10);
      sequence = lastSeq + 1;
    }
 
    const paddedSeq = sequence.toString().padStart(3, '0');
    const contactId = `CId-${month}-${year}-${paddedSeq}`;
 
    const newContact = new Contact({
      contactId,
      fullName,
      email,
      phone,
      companyName,
      designation,
      industry,
      location,
      Companylocation,
      serviceInterest,
      referralSource,
      message
    });
 
    await newContact.save();
 
    res.status(201).json({
      message: 'Contact submitted successfully',
      contact: newContact
    });
 
  } catch (error) {
    console.error('Error submitting contact form:', error);
    res.status(500).json({
      message: 'An error occurred while submitting the contact form',
      error: error.message
    });
  }
};
 
 
 
// Get All Contacts
exports.getAllContacts = async (req, res) => {
  try {
    const contacts = await Contact.find({ isDeleted: false }).sort({ createdAt: -1 });
    res.status(200).json({ contacts });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch contacts', error: error.message });
  }
};
 
// Get Contact by contactId
exports.getContactById = async (req, res) => {
  try {
    const { contactId } = req.params;
    const contact = await Contact.findOne({ contactId, isDeleted: false });
 
    if (!contact) {
      return res.status(404).json({ message: 'Contact not found' });
    }
 
    res.status(200).json({ contact });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch contact', error: error.message });
  }
};
 
 
 
 
exports.updateContact = async (req, res) => {
  try {
    const { contactId } = req.params;
    const { status, feedback } = req.body;
 
    const allowedStatuses = ['Pending', 'Accepted', 'Rejected'];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status value' });
    }
 
    const updatedContact = await Contact.findOneAndUpdate(
      { contactId, isDeleted: false },
      { status, feedback },
      { new: true }
    );
 
    if (!updatedContact) {
      return res.status(404).json({ message: 'Contact not found' });
    }
 
    // Send email only if status is Accepted or Rejected
    if (status === 'Accepted' || status === 'Rejected') {
      const sendStatusUpdateEmail = async (email, name, status, feedback) => {
        const subject =
          status === 'Accepted'
            ? 'Your Request Has Been Accepted!'
            : ' Your Request Was Not Approved';
 
        const message =
          status === 'Accepted'
            ? `<p>Hi ${name},</p>
               <p>Good news! Your request has been <strong>accepted</strong>.</p>`
            : `<p>Hi ${name},</p>
               <p>We regret to inform you that your request has been <strong>rejected</strong>.</p>`;
 
        const body = `
          ${message}
          ${feedback ? `<p><strong>Feedback:</strong> ${feedback}</p>` : ''}
          <p>Thank you for reaching out.<br/>Regards,<br/>AAS Technology Team</p>
        `;
 
        await sendEmail(subject, body, email);
      };
 
      //  UNCOMMENT and call the function
      await sendStatusUpdateEmail(
        updatedContact.email,
        updatedContact.fullName,
        status,
        feedback
      );
    }
 
    res.status(200).json({
      message: `Contact status updated to ${status}`,
      contact: updatedContact
    });
 
  } catch (error) {
    console.error(' Error updating contact status:', error);
    res.status(500).json({
      message: 'Failed to update contact status',
      error: error.message
    });
  }
};
 
 
 
// Soft Delete Contact
exports.deleteContact = async (req, res) => {
  try {
    const { contactId } = req.params;
    const deletedContact = await Contact.findOneAndUpdate(
      { contactId },
      { isDeleted: true },
      { new: true }
    );
 
    if (!deletedContact) {
      return res.status(404).json({ message: 'Contact not found' });
    }
 
    res.status(200).json({ message: 'Contact deleted (soft) successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete contact', error: error.message });
  }
};
 
 
// Get all contacts with status 'Accepted'
exports.getApprovedContacts = async (req, res) => {
  try {
    const  contacts  = await Contact.find({ status: 'Accepted', isDeleted: false });
 
    res.status(200).json(
      { contacts }
    );
  } catch (error) {
    console.error('Error fetching approved contacts:', error);
    res.status(500).json({
      success: false,
      message: 'Server Error',
    });
  }
};